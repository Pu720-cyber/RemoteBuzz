const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getMessaging } = require("firebase-admin/messaging");
initializeApp();

// Callable server endpoint. Configure Firebase App Check/authentication and
// rate limits before public production use. Never put Admin credentials in the APK.
exports.sendBuzz = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const code = String(request.data.code || "");
  if (!/^\\d{6}$/.test(code)) throw new HttpsError("invalid-argument", "Invalid pairing code.");
  await getMessaging().send({
    topic: `pair_${code}`,
    data: { action: "buzz" },
    android: { priority: "high", ttl: 30 * 1000 }
  });
  return { ok: true };
});
