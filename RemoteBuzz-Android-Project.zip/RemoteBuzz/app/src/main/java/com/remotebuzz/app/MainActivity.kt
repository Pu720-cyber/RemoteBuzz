package com.remotebuzz.app

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.widget.*
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : Activity() {
    private lateinit var codeInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        FirebaseAuth.getInstance().signInAnonymously()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply {
            text = "REMOTE BUZZ"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        codeInput = EditText(this).apply {
            hint = "Enter 6-digit pairing code"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            gravity = Gravity.CENTER
            textSize = 20f
        }
        val pair = Button(this).apply {
            text = "CONNECT"
            setOnClickListener { subscribeToCode() }
        }
        val buzz = Button(this).apply {
            text = "BUZZ"
            textSize = 28f
            minHeight = 150
            setOnClickListener { sendBuzz() }
        }
        val test = Button(this).apply {
            text = "Test this phone"
            setOnClickListener { vibrate() }
        }
        status = TextView(this).apply {
            text = "Enter the same code on both phones, then connect."
            gravity = Gravity.CENTER
            textSize = 16f
        }
        layout.addView(title)
        layout.addView(codeInput)
        layout.addView(pair)
        layout.addView(buzz)
        layout.addView(test)
        layout.addView(status)
        setContentView(layout)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun subscribeToCode() {
        val code = codeInput.text.toString().trim()
        if (!code.matches(Regex("\\d{6}"))) {
            status.text = "Please enter a valid 6-digit code."
            return
        }
        FirebaseMessaging.getInstance().subscribeToTopic("pair_$code")
            .addOnSuccessListener { status.text = "Connected. Share this code with the other phone." }
            .addOnFailureListener { status.text = "Connection failed: ${it.localizedMessage}" }
    }

    private fun sendBuzz() {
        val code = codeInput.text.toString().trim()
        if (!code.matches(Regex("\\d{6}"))) {
            status.text = "Enter and connect with a 6-digit code first."
            return
        }
        status.text = "Sending..."
        FirebaseFunctions.getInstance()
            .getHttpsCallable("sendBuzz")
            .call(hashMapOf("code" to code))
            .addOnSuccessListener { status.text = "Buzz signal sent." }
            .addOnFailureListener { status.text = "Send failed: ${it.localizedMessage}" }
    }

    private fun vibrate() {
        val vibrator = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(500)
        }
    }
}
