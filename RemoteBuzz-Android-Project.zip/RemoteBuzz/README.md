# Remote Buzz (Android starter project)

This is a starter Android/Firebase project for sending a vibration signal between Android phones over the internet.

## Important setup still required
1. Create a Firebase project.
2. Add an Android app with package name `com.remotebuzz.app`.
3. Download `google-services.json` and place it at `app/google-services.json`.
4. Enable Firebase Cloud Messaging and Realtime Database (the current UI scaffold subscribes to an FCM topic).
5. Enable Anonymous Authentication. Deploy the callable Cloud Function in `functions/` using Firebase CLI. Cloud Functions deployment may require the Firebase Blaze billing plan.
6. The button calls the `sendBuzz` callable function. Anonymous Authentication must be enabled in Firebase Authentication.
7. Add authentication, App Check, pairing-code expiry, and rate limiting before public use.

## Build
Run `gradle assembleDebug` after Firebase configuration. GitHub Actions also builds the APK and uploads it as an artifact.

## Android behavior limitations
High-priority FCM can wake an app process for a short data-message handler, but delivery is not guaranteed at every moment. Android force-stop, disabled notifications, Do Not Disturb, battery restrictions, no network, or vendor power management can prevent or delay vibration. A locked screen is supported subject to these OS settings.

## Security
Never embed Firebase Admin credentials or service-account keys in the Android APK. Pairing codes need authentication, expiration, abuse protection, and rate limiting.
